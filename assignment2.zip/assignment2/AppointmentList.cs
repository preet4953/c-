﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assignment2
{
    class AppointmentList
    {
        public List<Appointment> appointments = new List<Appointment>();
    }
}
