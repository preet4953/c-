﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab4
{
    class Person
    {
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public int Age { get; set; }
        public String BirthDate { get; set; }
        public String Country { get; set; }

    }
}
