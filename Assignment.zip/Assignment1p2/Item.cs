﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment1p2
{
    class Item
    {
        public String Name{get;set;}
        public double Price { get; set; }
    }
}
