﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab3
{
    class Person
    {
        public String Name { get; set; }
        public String CityName { get; set; }
        public String PassportNumber { get; set; }
        public int NumberOfBags { get; set; }
        public double TotalWeight { get; set; }


    }
}
