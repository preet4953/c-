﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections;
using System.Collections.ObjectModel;

namespace Assignment3
{
    //          Student Name:     Harpreet Singh
    //          Student Course    MSD Section 3 Term 1 May 2021
    //                            C# Assignment 3

    public partial class MainWindow : Window
    {
        public ArrayList al = new ArrayList();
        public ArrayList btnList = new ArrayList();


        String Seatselected = "";
        Button btnclick;
        public MainWindow()
        {
            InitializeComponent();

        }


        public void setItems(Button bt)
        {
            if (bt.Background == Brushes.Red)
            {
                bt.Background = Brushes.LimeGreen;
                bt.Foreground = Brushes.Black;
                SeatNumberDisplay.Text = " ";
                Seatselected = "";

            }
            else
            {
                Seatselected = bt.Name.ToString();
                SeatNumberDisplay.Text = Seatselected;
                bt.Background = Brushes.Red;
                bt.Foreground = Brushes.White;
                //bt.Opacity = 0.7;



            }



        }



        //Row D Seats
        private void D1_Click(object sender, RoutedEventArgs e)
        {
            setItems(D1);
            btnclick = D1;
           
            
            /*SeatNumberDisplay.Text = "D1";
            D1.Background = Brushes.Red;
            D1.Foreground = Brushes.White;
            D1.Opacity = 0.7;*/
        }

        private void D2_Click(object sender, RoutedEventArgs e)
        {
            setItems(D2);
            btnclick = D2;
           
        }

        private void D3_Click(object sender, RoutedEventArgs e)
        {
            setItems(D3);
            btnclick = D3;
            
        }

        private void D4_Click(object sender, RoutedEventArgs e)
        {
            setItems(D4);
            btnclick = D4;
           
        }

        //Row C Seats

        private void C1_Click(object sender, RoutedEventArgs e)
        {
            setItems(C1);
            btnclick = C1;
            
        }

        private void C2_Click(object sender, RoutedEventArgs e)
        {
            setItems(C2);
            btnclick = C2;
            
        }

        private void C3_Click(object sender, RoutedEventArgs e)
        {
            setItems(C3);
            btnclick = C3;
            
        }

        private void C4_Click(object sender, RoutedEventArgs e)
        {
            setItems(C4);
            btnclick = C4;
            
        }

        //Row B Seats
        private void B1_Click(object sender, RoutedEventArgs e)
        {
            setItems(B1);
            btnclick = B1;
            

        }

        private void B2_Click(object sender, RoutedEventArgs e)
        {
            setItems(B2);
            btnclick = B2;
            
        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            setItems(B3);
            btnclick = B3;
            
        }

        private void B4_Click(object sender, RoutedEventArgs e)
        {
            setItems(B4);
            btnclick = B4;
            
        }

        //Row A Seats
        private void A1_Click(object sender, RoutedEventArgs e)
        {
            setItems(A1);
            btnclick = A1;
            
        }

        private void A2_Click(object sender, RoutedEventArgs e)
        {
            setItems(A2);
            btnclick = A2;
            
        }

        private void A3_Click(object sender, RoutedEventArgs e)
        {
            setItems(A3);
            btnclick = A3;
            
        }

        private void A4_Click(object sender, RoutedEventArgs e)
        {
            setItems(A4);
            btnclick = A4;
            
        }

        // Confirm Button
        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            confirmedfunction();
            
        }

        //function
        private void confirmedfunction()
        {
            //i change
            if (al.Count != 16)
            {
                //These two if conditions
                if (UserInput.Text.Length != 0)
                {
                    if (Seatselected.Length != 0)
                    {
                        Seat s = new Seat();
                        s.CustomerName = UserInput.Text;
                        s.SeatNumber = Seatselected;
                        al.Add(s);

                        Textprint.Items.Clear();
                        foreach (Seat s2 in al)
                        {

                            Textprint.Items.Add(s2);

                        }

                        btnclick.Background = Brushes.Red;
                        UserInput.Text = "";
                        SeatNumberDisplay.Text = "";
                        Seatselected = "";
                        btnclick.IsEnabled = false;
                        /*Textprint.Items.Refresh();*/
                        btnList.Add(btnclick);
                        //Textprint.Items.Add("");
                    }
                    else { MessageBox.Show("Please Select a seat"); }

                }
                else
                {
                    MessageBox.Show(" Please Enter a customer name");
                    
                }

            }
            else
            {
                MessageBox.Show("We are Full! Please Either exit the Program or Delete some people from List");
            }

        }

        //delete Button
        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if(SearchInput.Text.Length!=0)
            {
                foreach(Seat s in al)
                {
                    if(s.CustomerName.ToLower().Equals(SearchInput.Text.ToLower()) || s.SeatNumber.Equals(SearchInput.Text))
                    {
                        al.Remove(s);
                        
                        btnEnable(s.SeatNumber);
                        Textprint.Items.Remove(s);
                        
                        return;
                    }

                }
                MessageBox.Show("Name/Number is Not in List");

            }
            else { MessageBox.Show("Enter Either Name or Seat Number"); }
        }
        private void btnEnable(String btn)
        {
            foreach(Button b in btnList)
            {
                if (btn.Equals(b.Name))
                {
                    MessageBox.Show("Seat Available!!!!",b.Name);
                    b.IsEnabled = true;
                    b.Background = Brushes.LimeGreen;
                    b.Foreground = Brushes.Black;
                }
            }
        }
    }
}
