﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment3
{
    class Seat
    {
        public String CustomerName { get; set; }
        public String SeatNumber { get; set;}

    }
}
