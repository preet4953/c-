﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HsFinalExam
{
    class Item
    {

        public string ItemNumber { get; set; }
        public int Cost { get; set; }
        public int Weight { get; set; }


        

    }
}
