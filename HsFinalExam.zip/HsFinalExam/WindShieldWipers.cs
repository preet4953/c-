﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HsFinalExam
{
    class WindShieldWipers:Item
    {
        public String ItemName { get; set; }
        public int Length { get; set; }
        public int ShippingPrice = 10;
    }
}
