﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HsFinalExam
{
    class Tyre:Item
    {

        public String ItemName { get; set; }
        public int Diameter { get; set; }
        public String ModelName { get; set; }
       
    }
}
